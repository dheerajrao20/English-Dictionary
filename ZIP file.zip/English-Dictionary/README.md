# English-Dictionary
This is an English Dictionary Made by using Django
